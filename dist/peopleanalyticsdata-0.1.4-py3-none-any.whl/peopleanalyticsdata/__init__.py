from .peopleanalyticsdata import list_sets, charity_donation, employee_survey, health_insurance, job_retention, managers, politics_survey, salespeople, soccer, sociological_data, speed_dating, ugtests, employee_performance, learning, graduates, promotion, recruiting 

__version__ = '0.1.4'
__author__ = 'Akshay Kotha'