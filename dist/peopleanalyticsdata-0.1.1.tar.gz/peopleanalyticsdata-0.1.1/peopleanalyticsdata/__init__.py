from .peopleanalyticsdata import charity_donation, employee_survey

__version__ = '0.1.0'
__author__ = 'Akshay Kotha'