# peopleanalytics-python

This effort is to port the package in R to Python. Please refer this [article](https://towardsdatascience.com/beginner-friendly-data-science-projects-accepting-contributions-3b8e26f7e88e) for more details on the same.

As an initial idea, trying to make the data available as an accessible python package which can be 'pip install ...' and called for statistical analysis and inference modeling.

This package will be providing a different set of data sets for budding data scientists to explore and analyze. Consider it as a alternative version of iris data sets and the similar ones on the UCI Machine Learning repository.

