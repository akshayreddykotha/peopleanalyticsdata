# peopleanalytics-python

This effort is to port the package in R to Python. Please refer this [article](https://towardsdatascience.com/beginner-friendly-data-science-projects-accepting-contributions-3b8e26f7e88e) for more details on the same.

As an initial idea, trying to make the data available as an accessible python package which can be 'pip install ...' and called for statistical analysis and inference modeling.

