This effort is to port the package in R to Python. 

As an initial idea, trying to make the data available as an accessible python package which can be 'pip install ...' and called for statistical analysis and inference modelling.